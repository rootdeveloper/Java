/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 * 1) Adicione os seguintes atributos na classe Agencia:
 * - numero (String)  
 * - banco (int) 
 */
class Agencia {
}
