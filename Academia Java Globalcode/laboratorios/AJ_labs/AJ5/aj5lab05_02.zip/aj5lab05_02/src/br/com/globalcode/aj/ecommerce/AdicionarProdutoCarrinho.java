/*
 * 1-) Este servlet devera ser mapeado dentro no web.xml!
 * 2-) Sera necessario alterar a variavel contexto para
 *     refletir nome colocado em app.name dentro do arquivo build.xml
 */
package br.com.globalcode.aj.ecommerce;

import br.com.globalcode.aj.dao.ProdutosDAO;
import br.com.globalcode.aj.dao.ProdutosDB;
import br.com.globalcode.beans.Produto;
import br.com.globalcode.util.GlobalcodeException;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdicionarProdutoCarrinho extends HttpServlet {
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    response.setContentType("text/html");
    // Obtencao do canal de envio de dados para o cliente
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head>");
    out.println("<title>Ecommerce : Academia do Java</title>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>");
    out.println("</head>");
    out.println("<body>");
    out.println("<link href= 'aj.css' rel='stylesheet' type='text/css'>");

    String nomeDaLoja = "XPTO Magazine";
    
    out.println("<H3>Suas compras em " + nomeDaLoja + "</H3>");    
    
    String strIdProduto = request.getParameter("idProduto");
    Produto prod = null;
    ProdutosDAO dao = new ProdutosDB();
    
    try {
      int idProduto = Integer.parseInt(strIdProduto);
      prod = dao.getProdutoById(idProduto);
    } catch (GlobalcodeException e) {
      throw new ServletException(e);
    } catch (RuntimeException e) {
      throw new ServletException(e);
    }
    
    out.println("<br/>id: <strong>" + prod.getId() + "</strong>");
    out.println("<br/>c&oacute;digo: <strong>" + prod.getCodigo() + "</strong>");
    out.println("<br/>nome: <strong>" + prod.getNome() + "</strong>");
    out.println("<br/>descri&ccedil;&atilde;o: <strong>" + prod.getDescricao() + "</strong>");
    out.println("<br/>pre&ccedil;o: <strong>" + prod.getPreco() + "</strong>");
    out.println("<br/><img src='imagem/" + prod.getImage()+ "' />");

    // Devemos imprimir somente o codigo do produto, pois esta e a unica informacao recebida.
    out.println("</body>");
    out.println("</html>");
  }
}
