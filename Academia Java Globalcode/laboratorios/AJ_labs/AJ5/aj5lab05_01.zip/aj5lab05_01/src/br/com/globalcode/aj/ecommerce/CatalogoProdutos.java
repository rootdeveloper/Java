/*
 * CatalogoProdutos.java
 *
 */
package br.com.globalcode.aj.ecommerce;

import br.com.globalcode.aj.dao.ProdutosDAO;
import br.com.globalcode.aj.dao.ProdutosDB;
import br.com.globalcode.util.GlobalcodeException;
import java.util.List;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CatalogoProdutos extends HttpServlet {
  
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
        ProdutosDAO produtosDB = new ProdutosDB();
        List listaProdutos = null;
        try {
            listaProdutos = produtosDB.getCatalogoProdutos();
        } catch (GlobalcodeException e) {
            throw new ServletException(e);
        }
        
        // ------------------------------------------------------------
        // Modifique este servlet para:
        // - Armazenar a lista de produtos no escopo de request, 
        //    com o nome "catalogo" 
        // - Encaminhar para o servlet CatalogoProdutosView, utilizando 
        //    um RequestDispatcher.
        //
        //  Nao esqueca de consultar o deployment descriptor !
        // ------------------------------------------------------------
        

        
  }
  
}
