/*
 * 1-) Este servlet devera ser mapeado dentro no web.xml!
 * 2-) Sera necessario alterar a variavel contexto para 
 *     refletir nome colocado em app.name dentro do arquivo build.xml
 */
package br.com.globalcode.aj.ecommerce;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdicionarProdutoCarrinho extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        // Obtencao do canal de envio de dados para o cliente
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Ecommerce : Academia do Java</title>");
        out.println("<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>");
        out.println("</head>");
        out.println("<body>");
        out.println("<link href= 'aj.css' rel='stylesheet' type='text/css'>");
        out.println("<H3>Adicionando produtos no carrinho de compras</H3>");
        
        // -------------------------------------------------------------------
        // Insira aqui as instrucoes para:
        //  a) leitura do parametro idProduto enviado na request
        //  b) inclusao do valor deste parametro no conteudo de resposta
        // -------------------------------------------------------------------
        
        
        // Devemos imprimir somente o codigo do produto, pois esta e a unica informacao recebida.        
        out.println("</body>");
        out.println("</html>");
    }
}
