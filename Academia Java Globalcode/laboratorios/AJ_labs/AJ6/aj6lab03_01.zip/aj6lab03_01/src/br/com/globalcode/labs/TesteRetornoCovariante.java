package br.com.globalcode.labs;

public class TesteRetornoCovariante {
    
 public static void main(String[] args){
     // Inicialize um objeto da classe Inteiro
     
     // Declare uma variavel chamada numero do tipo int para receber o retorno do metodo getNumero
     
     // Imprima o valor da variavel numero
     
     // Inicialize um objeto da classe Real
     
     // Declare uma variavel do tipo float para receber o retorno do metodo getNumero
     
     // Imprima o valor da variavel numero2
     
     
 }
}
