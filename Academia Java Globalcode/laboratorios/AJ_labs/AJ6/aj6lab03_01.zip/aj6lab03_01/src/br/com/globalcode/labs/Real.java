package br.com.globalcode.labs;
import java.util.*;

public class Real implements INumero {
    // Declare um atributo chamado numero do tipo float    
    
    // Declare um construtor que receba um float e inicialize o atributo numero    
    
    // Implemente o metodo getNumero retornando um Float ao inves de um Object (retorno covariante)
    
}
