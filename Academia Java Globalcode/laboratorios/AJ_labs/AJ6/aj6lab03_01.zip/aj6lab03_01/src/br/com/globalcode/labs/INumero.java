package br.com.globalcode.labs;

public interface INumero {
    // Repare que o tipo de retorno � Object
    public Object getNumero();
}
