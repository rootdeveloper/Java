package br.com.globalcode.labs;
import java.util.*;

public class LabFormatadores {
    public static void main(String[] args){
        
        // Informe a data no formato dd/mm/yyyy e a hora completa hh:mm:ss
        Date data = new Date();
        
        // Mostre o n�mero inteiro com 6 d�gitos e zeros � esquerda e o n�mero double com as 2 decimais
        int i = 101;
        double numero = 23.45;
        
        
    }
}
