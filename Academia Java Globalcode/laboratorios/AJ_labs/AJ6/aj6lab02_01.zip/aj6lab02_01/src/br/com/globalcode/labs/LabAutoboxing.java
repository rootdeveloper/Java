package br.com.globalcode.labs;
import java.util.*;

public class LabAutoboxing {
    public static void main(String[] args){
        int i = 10;
        List numeros = new ArrayList();
        // Adicione a variavel i ao List numeros
        
        // Obtenha o primeiro elemento do List numeros e armazene novamente na variavel i e imprima o valor
        
        Integer i2 = new Integer(10);
        Integer total;
        // Some os valores de i2 e i e armazene na variavel total e imprima o valor
        
        
        // Some os valores da variavel total e da variavel i e armazene na variavel i novamente e imprima o valor
                
    }
}
