package br.com.globalcode.labs;

enum Operacao {
  MAIS   { double eval(double x, double y) { return x + y; } },
  MENOS  { double eval(double x, double y) { return x - y; } },
  VEZES  { double eval(double x, double y) { return x * y; } },
  DIVIDE { double eval(double x, double y) { return x / y; } };

  abstract double eval(double x, double y);
}

public class LabEnumeration {
    public static void main(String[] args){
        double x = 4;
        double y = 3;
        // exiba o resultado de todas as opera��es com os n�meros x e y

    
    }
}
