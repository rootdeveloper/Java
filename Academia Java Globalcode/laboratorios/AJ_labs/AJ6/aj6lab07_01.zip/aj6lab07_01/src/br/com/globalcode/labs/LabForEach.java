package br.com.globalcode.labs;
import java.util.*;

public class LabForEach {
    public static void main(String[] args){
        comVarargs(1,3,5,7);
        comVarargs2("Maria", "Joao", "Alice");
    }
    public static void comVarargs(int ... numeros){
        // Utilize o novo for para imprimir os numeros
        
    }
    public static void comVarargs2(String ... nomes){
        // Utilize o novo for para imprimir os nomes
        
    }
}
