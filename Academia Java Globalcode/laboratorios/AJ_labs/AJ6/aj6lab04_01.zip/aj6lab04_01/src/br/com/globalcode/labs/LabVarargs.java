package br.com.globalcode.labs;
import java.util.*;

public class LabVarargs {
    
    // Declare um metodo estatico e void que receba um numero variavel de variaveis do tipo int
    // Imprima todos os numeros

    
    // Declare um metodo estatico e void que receba um numero variavel de variaveis do tipo String
    // Imprima todos os valores
    
    
    public static void main(String[] args){
        // Teste os m�todos passando parametros
    }
}
