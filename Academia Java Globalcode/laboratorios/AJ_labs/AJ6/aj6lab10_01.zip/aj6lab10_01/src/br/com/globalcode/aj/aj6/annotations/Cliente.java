package br.com.globalcode.aj.aj6.annotations;
public class Cliente {
  
  private int codigo;
  
  @GUIVisible
  private String nome;

  @GUIVisible
  private String endereco;
  
  public int getCodigo() {
    return codigo;
  }
  public void setCodigo(int codigo) {
    this.codigo = codigo;
  }

  public String getNome() {
    return nome;
  }
  public void setNome(String nome) {
    this.nome = nome;
  }
  
}
