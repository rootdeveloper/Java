package br.com.globalcode.aj.aj6.annotations;

import javax.swing.JFrame;

/**
 *
 * @author felipeal
 */
public class Main {
  
  public static void main(String[] args) {
    JFrame frame = new JFrame( "GUI Generator" );
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    GUIGenerator generator = new GUIGenerator();
    Cliente cliente = new Cliente();
    generator.bind( cliente );
    frame.getContentPane().add( generator );
    frame.pack();
    frame.setVisible(true);
  }
  
}
