/*
 * BubbleSort.java
 *
 * Created on 22 de Mar�o de 2006, 10:35
 *
 */
package br.com.globalcode.util;

import java.util.Observable;

/**
 * 
 * @author Globalcode
 */
public class BubbleSort extends Observable /* solucao --> */implements Runnable {

    private Comparable[] elementos;

    public BubbleSort(Comparable[] elementos) {
        this.elementos = elementos;
    }

    public void ordenar() {
        for (int limite = elementos.length - 1; limite > 0; limite--) {
            for (int j = 0; j < limite; j++) {
                if (elementos[j].compareTo(elementos[j + 1]) > 0) {
                    Comparable temp = elementos[j + 1];
                    elementos[j + 1] = elementos[j];
                    elementos[j] = temp;
                    setChanged();
                    notifyObservers(elementos);
                    Thread.yield();
                }
            }
        }
        setChanged();
        notifyObservers(Boolean.TRUE);
    }

    private void delay(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // solucao
    public void run() {
        ordenar();
    }
}
