/*
 * GlobalcodeException.java
 *
 */
package br.com.globalcode.util;

/**
 * 
 * @author Globalcode
 */
public class GlobalcodeException extends Exception {

    /** Creates a new instance of GlobalcodeException */
    public GlobalcodeException(Throwable t) {
        super(t);
    }
}
