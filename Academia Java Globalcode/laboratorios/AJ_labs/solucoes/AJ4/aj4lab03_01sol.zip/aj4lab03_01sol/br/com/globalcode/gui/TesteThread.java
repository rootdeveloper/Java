/*
 * TesteThread.java
 *
 * Created on 22 de Mar�o de 2006, 19:58
 *
 */
package br.com.globalcode.gui;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

/**
 * 
 * @author Globalcode
 */
public class TesteThread {

    static final int QUANTIDADE_MAXIMA = 300;
    static final String NOME_ARQUIVO_LISTAGEM = "nomes.txt";

    public static void main(String[] args) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        PainelDigitacao painelDig = new PainelDigitacao();
        PainelOrdenacao painelOrd = new PainelOrdenacao(new File(NOME_ARQUIVO_LISTAGEM), QUANTIDADE_MAXIMA);
        JInternalFrame iframeDig = new JInternalFrame("Digitacao");
        JInternalFrame iframeOrd = new JInternalFrame("Ordenacao");
        iframeDig.getContentPane().add(painelDig);
        iframeOrd.getContentPane().add(painelOrd);
        iframeDig.setBounds(10, 10, 300, 500);
        iframeOrd.setBounds(320, 10, 300, 500);
        iframeDig.setResizable(true);
        iframeOrd.setResizable(true);
        iframeDig.setVisible(true);
        iframeOrd.setVisible(true);
        JDesktopPane deskPane = new JDesktopPane();
        deskPane.add(iframeDig);
        deskPane.add(iframeOrd);
        JFrame frame = new JFrame("TesteThread");
        frame.setContentPane(deskPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setBounds((screenSize.width - 640) / 2, (screenSize.height - 560) / 2, 640, 560);
        frame.setVisible(true);
    }
}
