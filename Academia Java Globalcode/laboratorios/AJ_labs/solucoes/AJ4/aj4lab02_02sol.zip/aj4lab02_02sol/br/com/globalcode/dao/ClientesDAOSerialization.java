/**
 * @author Globalcode
 */
/*
 * Globalcode - "The Developers Company"
 *
 * Academia do Java
 *
 *
 */
package br.com.globalcode.dao;

import br.com.globalcode.io.FiltroClientes;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import br.com.globalcode.beans.Cliente;
import br.com.globalcode.util.GlobalcodeException;

public class ClientesDAOSerialization implements ClientesDAO {
    
    public void salvar(Cliente cliente) throws GlobalcodeException {
        File f = new File("Cliente" + cliente.getCpf() + ".ser");
        
        if (cliente.getId() == 0) {
            // definicao de id por sorteio
            cliente.setId(1 + (int) (999999 * Math.random()));
        }
        
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(f);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(cliente);
            fos.close();
        } catch (FileNotFoundException e) {
            throw new GlobalcodeException(e, "Arquivo Inexistente!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void excluir(String cpf) throws GlobalcodeException {
        File f = new File("Cliente" + cpf + ".ser");
        boolean apagou = f.delete();
        if (apagou == false) {
            String msg = "Impossivel remover o arquivo " + f.getName() 
                          + " - deve estar sendo utilizado por outro processo";
            throw new GlobalcodeException(msg);
        }
    }
    
    public List getAllClientes() throws GlobalcodeException {
        
        // este objeto representa o diretorio de trabalho atual
        File diretorioAtual = new File(".");
        try {
            System.out.println("diretorio atual:" + diretorioAtual.getCanonicalPath());
        } catch (IOException ex) {
            System.out.println("Erro ao obter nome completo do diretorio atual: " + ex.getMessage());
        }
        
        /*
         * Instrucoes
         * ----------
         *
         * 1. Instancie o filtro de arquivos que esta localizado 
         * no pacote br.com.globalcode.io
         *
         * 2. Utilize metodo .list(...) do objeto diretorioAtual
         * para localizar todos os nomes de arquivos que cont�m objetos 
         * serializados da classe Cliente.
         */
        FilenameFilter filtro = null;
        String[ ] nomesArquivosFiltrados = null;
        
        
        // solucao
        filtro = new FiltroClientes();
        nomesArquivosFiltrados = diretorioAtual.list(filtro);
        
        
        // montagem da lista de clientes recuperados do sistema de arquivos
        ArrayList todosClientes = new ArrayList();
        for (int i = 0; i < nomesArquivosFiltrados.length; i++) {
            
             /*
              * Observacao:
              * Como a palavra cliente tem 7 caracteres e a extensao (.ser) ocupa 4 caracteres
              * podemos utilizar o seguinte comando para obtermos somente o cpf, eliminando
              * o inicio (Cliente) e o fim (.ser)
              * String cpf = umArquivo.substring(7,umArquivo.length() -4 );
              */
            String umArquivo = nomesArquivosFiltrados[i];
            String cpf = umArquivo.substring(7, umArquivo.length() - 4);
            Cliente umCliente = getClienteByCPF(cpf);
            todosClientes.add(umCliente);
            
        }
        
        return todosClientes;
        
    }
    
    public Cliente getClienteByCPF(String cpf) throws GlobalcodeException {
        File f = new File("Cliente" + cpf + ".ser");
        FileInputStream fis;
        Cliente c = null;
        try {
            fis = new FileInputStream(f);
            ObjectInputStream ois = new ObjectInputStream(fis);
            c = (Cliente) ois.readObject();
            fis.close();
            return c;
        } catch (IOException e) {
            throw new GlobalcodeException(e, "Erro ao executar operaceo de leitura");
        } catch (ClassNotFoundException e) {
            throw new GlobalcodeException(e, "Erro ao localizar a classe Cliente.class");
        }
    }
}
