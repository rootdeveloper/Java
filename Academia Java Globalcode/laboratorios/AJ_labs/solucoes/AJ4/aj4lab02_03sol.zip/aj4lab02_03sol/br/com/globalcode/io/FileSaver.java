package br.com.globalcode.io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import br.com.globalcode.util.GlobalcodeException;

/*
 * Importante:
 * Este codigo sera utilizado pela classe EditorTexto por isto:
 *  
 * 1. Nao altere a assinatura dos metodos desta classe, ou seja, mantenha todos 
 * os modificadores, os parametros e as exceptions lan�adas.
 * 2. Nao altere o nome desta classe
 * 3. Implemente os metodos conforme especificado abaixo
 * 4. Depois que a classe FileSaver estiver testada e funcionando execute a classe 
 * EditorTexto e analise seu codigo.
 * 
 * OBS: Na abertura dos arquivos, o texto aberto estara deslocado em rela�ao a
 * atual tela. Para confirmar a abertura do arquivo, utilize as barras de rolagem 
 * na tela de edi�ao.
 * 
 */
public class FileSaver {

    public static void save(String texto, String fileName) throws GlobalcodeException {
        // Utilizando a classe FileWriter implemente este metodo de forma que o texto seja
        // gravado no arquivo indicado pelo parametro fileName.
        // - opcionalmente a classe BufferedWriter pode ser utilizada
        // - nao se esqueca de executar os metodos flush e close nos seus streams de caracteres
        
        // solucao
        try {
            FileWriter writer = new FileWriter(fileName);
            
            // 1a. opcao - array de caracteres
            writer.write(texto.toCharArray()); 
            
            // 2a. opcao - string completa
            //BufferedWriter bufferedWriter = new BufferedWriter(writer);
            //bufferedWriter.write(texto);
            //bufferedWriter.flush();
            //bufferedWriter.close();

            writer.flush();
            writer.close();

            
        } catch (IOException e) {
            throw new GlobalcodeException(e, "Erro ao salvar arquivo " + fileName);
        }
    }

    public static String read(String fileName) throws GlobalcodeException {
        
        // Utilizando a classe FileReader implemente este metodo de forma que o texto seja
        // lido do arquivo indicado pelo parametro fileName 
        // - opcionalmente a classe BufferedReader pode ser utilizada
        // - nao se esqueca de executar os metodos close nos seus streams de caracteres

        // solucao
        try {
            
            FileReader reader = new FileReader(fileName);
            StringBuffer stringBuffer = new StringBuffer();
            
            // 1a. opcao - caracter a caracter
            int leitura = 0;
            while ((leitura = reader.read()) != -1) {
                char caracterRecuperado = (char) leitura;
                stringBuffer.append(caracterRecuperado);
            }
            
            // 2a. opcao - linha a linha
            //BufferedReader bufferedReader = new BufferedReader(reader);
            //String linha = null; 
            //while ((linha = bufferedReader.readLine()) != null) {
            //    stringBuffer.append(linha);
            //    stringBuffer.append('\n');
            //}
            //bufferedReader.close();
            
            reader.close();
            return stringBuffer.toString();
            
        } catch (IOException e) {
            throw new GlobalcodeException(e, "Erro ao recuperar texto do arquivo " + fileName);
        }
        
    }
}
