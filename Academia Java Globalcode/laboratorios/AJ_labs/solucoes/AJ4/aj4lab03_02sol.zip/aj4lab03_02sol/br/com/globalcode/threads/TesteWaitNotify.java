/*
 * TesteWaitNotify.java
 *
 * Created on 23 de Mar�o de 2006, 15:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package br.com.globalcode.threads;


import javax.swing.JOptionPane;

public class TesteWaitNotify {

   public static void main(String args[]) throws Exception {

     // inicializando repositorio de dados 
     ListaConvidados lista = new ListaConvidados();

      EntregadorDeConvite e1 = new EntregadorDeConvite(1, lista);
      EntregadorDeConvite e2 = new EntregadorDeConvite(2, lista);
      // disparando entregadores de convites
      // s�o as threads consumidoras do reposit�rio de dados
      e1.start();
      e2.start();
      
      /*
       * inicializar uma terceira thread de entrega de convites
       */
      // solucao
      EntregadorDeConvite e3 = new EntregadorDeConvite(3, lista);
      e3.start();
      
      // loop de entrada de dados
      // esta thread (main) � a produtora de dados 
      while (true) {
        // otem um novo email para adicionar na lista
        String email = JOptionPane.showInputDialog("Digite o email do proximo convidado ", "");
        if (email != null) {
          lista.adicionar(email);
        } else {
          lista.fecharLista();
          break; // para sair do loop
        }
      }

   }

}
