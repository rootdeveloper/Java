/*
 * ReceptorNomesDigitados.java
 *
 *
 */
package br.com.globalcode.util;

public interface ReceptorNomesDigitados {

    public void receberNomesDigitados(Comparable[] nomes) throws GlobalcodeException;
}
