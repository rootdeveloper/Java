/*
 * @author Globalcode 
 *
 * TesteRecuperacao.java
 *
 */

package br.com.globalcode.teste;

import br.com.globalcode.beans.Cliente;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TesteRecuperacao {
    

    public static void main(String[] args) {
        
        String cpf = "11232404-6";
        String nomeArquivo = "Cliente" + cpf + ".ser";
        
        try {
            
            FileInputStream leitor = new FileInputStream(nomeArquivo);
            
            /* 
             * 1. Instancie um stream de leitura de objetos
             * baseado no stream de arquivos "leitor".
             *
             * 2. Atraves do stream de leitura de objetos
             * tente recuperar um objeto gravado no arquivo 
             * (lembre-se de incluir um cast down).
             *
             */
            ObjectInputStream leitorObjetos = null;
            Cliente clienteRecuperado = null;
            
            
            // solucao
            leitorObjetos = new ObjectInputStream(leitor);
            clienteRecuperado = (Cliente) leitorObjetos.readObject();

            
            
            System.out.println("cliente recuperado: " + clienteRecuperado);
            
            
        } catch (IOException e) {
            System.out.println("Erro na operacao de I/O");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("A classe dos clientes nao foi localizada");
            e.printStackTrace();
        }
        
    }
    
}
