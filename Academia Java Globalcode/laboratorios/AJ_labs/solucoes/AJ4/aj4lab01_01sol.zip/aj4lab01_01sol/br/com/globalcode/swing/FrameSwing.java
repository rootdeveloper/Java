package br.com.globalcode.swing;

import javax.swing.*;

public class FrameSwing extends JFrame {

    public FrameSwing() {
        super("Janela Swing");
        // Utilizamos a constante declarada na classe JFrame para definir
        // o comportamento padrao no fechamento da janela
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(275, 100);
        this.setVisible(true);
    }

    public static void main(String args[]) {
        FrameSwing t = new FrameSwing();
    }
}
