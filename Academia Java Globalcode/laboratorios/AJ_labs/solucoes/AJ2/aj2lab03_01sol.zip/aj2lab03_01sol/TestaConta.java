/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
public class TestaConta {

    public static void main(String[] args) {
        // Criar um objeto do tipo Conta
        Conta c = new Conta();
        // Usar o metodo inicializaConta para fazer a inicializacao do objeto criado
        c.inicializaConta(1000.0, "1040-8", "Jo�o da Silva", 254, 104);
        // executar um deposito
        c.deposito(200);
        // Imprimir o saldo apos o deposito
        c.imprimeDados();
        // executar um saque cujo valor seja menor que o saldo
        c.saque(1000);
        // Imprimir o saldo apos o deposito
        c.imprimeDados();
        // executar uma retirada cujo valor seja maior que o saldo
        c.saque(500);
        // Imprimir o saldo apos o deposito
        c.imprimeDados();
    }
}
