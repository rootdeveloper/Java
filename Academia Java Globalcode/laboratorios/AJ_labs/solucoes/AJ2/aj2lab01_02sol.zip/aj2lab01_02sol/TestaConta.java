/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaConta {

    public static void main(String[] args) {
        // Criacao da conta
        Conta c = new Conta();
        // Inicializacao da conta
        c.inicializaConta(1000.0, "1040-8", "Jo�o da Silva", 254, 104);
        // Impressao dos dados da conta
        c.imprimeDados();
        // Saque da conta
        c.saque(500);
        // Impressao dos dados da conta
        c.imprimeDados();
        // Deposito em conta
        c.deposito(200);
        // Impressao dos dados da conta
        c.imprimeDados();
    }
}
