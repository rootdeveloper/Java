/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaCliente {

    public static void main(String[] args) {
        // Criacao do cliente
        Cliente c = new Cliente();
        // Inicializacao do cliente
        c.inicializaCliente("Marcio Prudente", "545.785.458-89");
        // Impressao dos dados do cliente
        c.imprimeDados();
    }
}
