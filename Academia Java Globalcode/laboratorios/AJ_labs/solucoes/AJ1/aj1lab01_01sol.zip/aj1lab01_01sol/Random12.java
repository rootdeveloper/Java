/*
 * Crie uma classe que gere um numero aleatorio entre os valores maximo 
 * e minimo recebidos do usuario atraves do metodo main.
 */
class Random12 {

    public static void main(String[] args) {
        if (args.length == 2) {
            // Supondo-se que o primeiro argumento seja sempre o de menor valor
            int limInferior = Integer.parseInt(args[0]);
            int limSuperior = Integer.parseInt(args[1]);
            /*
             * Como temos interesse que sejam obtidos valores aleatorios entre o 1o. e o 2o. numeros, temos que tomar o
             * valor minimo como o valor base. Como entao obteremos os valores intermediarios?!?!?! Se pegarmos o limite
             * superior e subtrairmos do limite inferior, temos um espec- tro que desejamos que o valor seja alterado.
             * Entao, se tivermos o minimo de 50 e o maximo de 100, o espectro de valores a serem alterados e de 50.
             * Mas, como podemos determinar um numero dentro deste espectro usando os valores randomicos? Recordando que
             * o random retorna valores de 0 a 0.9999999...., e se multiplicarmos o valor do espectro pelo numero
             * randomico estaremos obtendo sempre os valores dentro do espectro definido. Tomando-se entao 50*0.5 = 25,
             * ou seja, se pegarmos o valor do espectro multiplicarmos o valor randomico e somarmos ao valor minimo
             * sempre obteremos esse os valore dentro do range especificado
             */
            double valorAleatorio = limInferior + (limSuperior - limInferior) * Math.random();
            System.out.println(valorAleatorio);
        } else {
            System.out.println("Sintaxe: java Random12 <numeroMaximo> <numeroMinimo>");
        }
    }
}
