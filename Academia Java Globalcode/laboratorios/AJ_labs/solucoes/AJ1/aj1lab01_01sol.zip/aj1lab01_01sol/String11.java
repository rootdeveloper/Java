/*
 * Crie uma classe que leia um parametro passado na linha de comando no seguinte formato:
 * dd/mm/aaaa 
 * Desta maneira, a classe devera ser executada como java String11 11/09/2001
 * A saida gerada por essa execucao deve ser a impressao separada do dia, do mes e do ano
 * utilizando apenas os metodos da classe String.
 */
class String11 {

    public static void main(String args[]) {
        String dataSeparada[] = { "", "", "" };
        // coloque aqui o seu codigo
        if (args.length == 1) {
            String data = args[0];
            dataSeparada[0] = data.substring(0, 2); // Captura o string na posi�ao 0 ate a posi�ao 1 (lembre-se da
            // regra, numero - 1)
            dataSeparada[1] = data.substring(3, 5); // Captura o string na posi�ao 3 ate a posi�ao 4 (lembre-se da
            // regra, numero - 1)
            dataSeparada[2] = data.substring(6, 10); // Captura o string na posi�ao 6 ate a posi�ao 9 (lembre-se da
            // regra, numero - 1)
            System.out.println("dia: " + dataSeparada[0]);
            System.out.println("mes: " + dataSeparada[1]);
            System.out.println("ano: " + dataSeparada[2]);
        } else {
            System.out.println("Sintaxe: java String11 <data>");
        }
    }
}
