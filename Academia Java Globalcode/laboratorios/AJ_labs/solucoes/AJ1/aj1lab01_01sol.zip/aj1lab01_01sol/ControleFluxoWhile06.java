/*
 *
 * 1) Quantos numeros divisiveis por 6 existem entre 14 e 1578? 
 * Comprove utilizando um laco while.
 * 
 */
class ControleFluxoWhile06 {

    public static void main(String[] args) {
        int limiteInferior = 13;
        int limiteSuperior = 130;
        int numerosDiv6 = 0; // Aqui voce armazena a quantidade de numeros divisiveis por 6
        // Codigo para verificar quantos numeros divisiveis por 6 existem entre o limiteInferior e o limiteSuperior
        int i = limiteInferior;
        while (i <= limiteSuperior) {
            if (i % 6 == 0) {
                numerosDiv6++;
            }
            i++;
        }
        String texto = "Quantidade de numeros divisiveis por 6 entre ";
        System.out.println(texto + limiteInferior + " e " + limiteSuperior + " e : " + numerosDiv6);
    }
}
