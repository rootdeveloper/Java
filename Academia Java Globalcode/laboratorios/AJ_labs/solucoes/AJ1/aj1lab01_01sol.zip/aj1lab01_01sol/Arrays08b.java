/* 
 * Utilizando dois lacos for, imprima todos os elementos do seguinte array:
 * 
 * int array1[][] = {{1,6,7},{2,5,1,0},{2,4,1,2,1}}; 
 */
class Arrays08b {

    public static void main(String args[]) {
        int array1[][] = { { 1, 6, 7 }, { 2, 5, 1, 0 }, { 2, 4, 1, 2, 1 } };
        for (int i = 0; i < array1.length; i++) {
            for (int j = 0; j < array1[i].length; j++) {
                System.out.println("Valor de array[" + i + "][" + j + "] = " + array1[i][j]);
            }
        }
    }
}
