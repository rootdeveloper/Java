/*
 * 1)Criar uma variavel do tipo boolean para armazenar se a pessoa e CLT (true) ou autonoma (false) 
 * 2)Vamos utilizar o condicional if para atender as seguintes especificacoes:
 * - Quando o sexo for masculino (M) imprimir:
 *    O Senhor <nome da pessoa>  e portador do rg... 
 * - Quando o sexo for feminino (F) imprimir:
 *    A Senhora <nome da pessoa> e portadora do rg ..
 * - Quando o sexo for invalido (diferente de F ou M) imprimir:
 *    O Senhor(a) <nome da pessoa> e portador(a)
 * - Quando a pessoa for CLT imprimir:
 *    esta registrado com o salario de R$ <salario>
 * - Quando a pessoa for Autonoma imprimir:
 *    foi contratado pelo valor de R$ <salario>
 */
class ControleFluxoIf03 {

    public static void main(String[] args) {
        String nome;
        String dataNascimento;
        String rg;
        char sexo; // UTILIZE 'M' para MASCULINO e 'F' para FEMININO
        float salario;
        boolean clt; // Variavel adicionada
        nome = "Manuel da Silva";
        dataNascimento = "22/04/1980";
        rg = "29345432";
        sexo = 'M';
        salario = 2500.00f;
        clt = true; // Atribui�ao do valor
        // Linhas utilizadas caso nao haja uma defini�ao de qual o sexo da pessoa - situa�ao default
        String textNome = "O(A) Senhor(a) " + nome + ", ";
        String textRg = "portador(a) do rg de numero " + rg + ", \n";
        // Executa a analise do sexo. Observe que estamos usando a variavel
        // textNome e textRg que foram inicializadas anteriormente.
        // Se declararmos dentro do bloco if estas Strings, nao conse-
        // guiremos utiliza-las posteriormente. Lembre-se do conceito de escopo!
        if (sexo == 'M') {
            textNome = "O Senhor " + nome + ", ";
            textRg = "portador do rg de numero " + rg + ", \n";
        } else if (sexo == 'F') {
            textNome = "A Senhora " + nome + ", ";
            textRg = "portadora do rg de numero " + rg + ", \n";
        }
        String textNasc = "nascido em " + dataNascimento + ", ";
        String textSexo = " do sexo " + sexo + ", ";
        // Inicializa�ao da variavel text$ que ira ser utilizada para imprimir os dados do usuario.
        String text$ = "";
        // Note que estaremos reatribuindo um outro valor posteriormente
        if (clt) {
            text$ = " esta registrado com o salario de R$ " + salario;
        } else {
            text$ = " foi contratado pelo valor de R$ " + salario;
        }
        System.out.println(textNome + textRg + textNasc + textSexo + text$);
    }
}
