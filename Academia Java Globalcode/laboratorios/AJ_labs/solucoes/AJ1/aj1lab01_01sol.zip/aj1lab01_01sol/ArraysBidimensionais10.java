/*
 * Declare e inicialize um array de Strings bidimensional, representando a agenda semanal de uma pessoa
 *  
 * array[0] = compromissos da segunda-feira 
 *        array[0][0] = compromissos da manha
 *        array[0][1] = compromissos da tarde
 *        array[0][2] = compromissos da noite
 * array[1] = compromissos da terca-feira 
 *        array[1][0] = compromissos da manha
 *        array[1][1] = compromissos da tarde
 *        array[1][2] = compromissos da noite
 * array[2] = compromissos da quarta-feira  
 *        array[2][0] = compromissos da manha
 *        array[2][1] = compromissos da tarde
 *        array[2][2] = compromissos da noite
 * array[3] = compromissos da quinta-feira 
 *        array[3][0] = compromissos da manha
 *        array[3][1] = compromissos da tarde
 *        array[3][2] = compromissos da noite
 * array[4] = compromissos da sexta-feira 
 *        array[4][0] = compromissos da manha
 *        array[4][1] = compromissos da tarde
 *        array[4][2] = compromissos da noite
 * array[5] = compromissos da sabado 
 *        array[5][0] = compromissos da manha
 *        array[5][1] = compromissos da tarde
 *        array[5][2] = compromissos da noite
 * array[6] = compromissos da domingo
 *        array[6][0] = compromissos da manha
 *        array[6][1] = compromissos da tarde
 *        array[6][2] = compromissos da noite
 */
class ArraysBidimensionais10 {

    public static void main(String[] args) {
        String[] periodos = { "manha", "tarde", "noite" };
        String[] dias = { "domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado" };
        String[][] agenda = new String[7][3];
        for (int i = 0; i < dias.length; i++) {
            for (int j = 0; j < periodos.length; j++) {
                agenda[i][j] = "Compromissos de " + dias[i] + " no periodo " + periodos[j];
            }
        }
        for (int i = 0; i < agenda.length; i++) {
            for (int j = 0; j < agenda[i].length; j++) {
                System.out.println(agenda[i][j]);
            }
        }
    }
}
