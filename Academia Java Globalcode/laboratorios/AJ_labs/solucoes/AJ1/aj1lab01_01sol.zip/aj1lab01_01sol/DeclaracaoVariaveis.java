/*
 * Declare, inicialize e imprima variaveis de acordo com a especificacao abaixo:
 *
 * 1)Declare uma variavel do tipo String para armazenar o nome de uma pessoa
 * 2)Declare uma variavel do tipo String para armazenar a data de nascimento de uma pessoa
 * 3)Declare uma variavel do tipo String para armazenar o rg de uma pessoa
 * 4)Declare uma variavel do tipo caracter para armazenar o sexo da pessoa utilizando a seguinte regra,  
 *   MASCULINO(M) e FEMININO (F) 
 * 5)Declare uma variavel do tipo double para armazenar o salario da pessoa 
 * 6)Inicialize todas as variaveis
 * 7)Imprima todos os valores de maneira a obter a seguinte saida:
 * O Senhor(a) <nome da pessoa>, portador(a) do rg de numero <rg>, 
 * nascido em <data nascimento>, do sexo <M|F>, esta registrado com o salario de R$ <salario>
 *    
 * Lembre-se que voce pode utilizar os caracteres de escape na impressao:
 * \n :pular linha
 * \t :tab
 * \\ : \
 * \" : "
 */
class DeclaracaoVariaveis {

    public static void main(String[] args) {
        // 1)Declare uma variavel do tipo String para armazenar o nome de uma pessoa
        String nome;
        // 2)Declare uma variavel do tipo String para armazenar a data de nascimento de uma pessoa
        String dataNascimento;
        // 3)Declare uma variavel do tipo String para armazenar o rg de uma pessoa
        String rg;
        // 4)Declare uma variavel do tipo caracter para armazenar o sexo da pessoa utilizando a seguinte regra,
        // MASCULINO(M) e FEMININO (F)
        char sexo;
        // 5)Declare uma variavel do tipo double para armazenar o salario da pessoa
        double salario;
        // 6)Inicialize todas as variaveis
        nome = "Jose dos Santos";
        dataNascimento = "01/01/2001";
        rg = "111222333-4";
        sexo = 'M';
        salario = 1000;
        // 7)Imprima todos os valores
        System.out.println("O(A) Senhor(a) " + nome + ", portador(a) do rg de numero" + rg + ",\n" + "nascido em " + dataNascimento + ", do sexo " + sexo + ", esta registrado \n"
                + "com o salario de R$" + salario);
    }
}
