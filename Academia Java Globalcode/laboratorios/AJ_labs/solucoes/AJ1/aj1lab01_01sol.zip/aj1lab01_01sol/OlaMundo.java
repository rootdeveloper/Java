/*
 * 
 * Para COMPILAR esta classe via prompt: javac OlaMundo.java 
 * Para EXECUTAR a classe via prompt: java OlaMundo 
 * 
 * Lembre-se:
 *  Java e case senstive, por isto OlaMundo.java e diferente de olamundo.java
 *  Nao coloque a extensao .class ao executar a classe
 */
class OlaMundo {

    public static void main(String[] args) {
        System.out.println("Coloque o seu texto aqui...");
    }
}
