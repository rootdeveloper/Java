/*
 * 
 * 1) Crie um laco while que imprima os caracteres de F a Z maiusculos, incluindo o F e o Z utilizando 
 * o operador de pos incremento (i++)
 *
 */
class ControleFluxoWhile05 {

    public static void main(String[] args) {
        char letra = 'F';
        while (letra <= 'Z') {
            System.out.println(letra);
            letra++;
        }
    }
}
