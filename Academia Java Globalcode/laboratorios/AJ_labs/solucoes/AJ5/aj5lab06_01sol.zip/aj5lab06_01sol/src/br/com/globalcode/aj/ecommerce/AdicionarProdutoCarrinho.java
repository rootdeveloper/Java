package br.com.globalcode.aj.ecommerce;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import br.com.globalcode.aj.dao.ProdutosDAO;
import br.com.globalcode.aj.dao.ProdutosDB;
import br.com.globalcode.beans.CarrinhoCompras;
import br.com.globalcode.beans.Item;
import br.com.globalcode.beans.Produto;
import br.com.globalcode.util.GlobalcodeException;

/*  ------------------------------------------------
 *  NAO MODIFIQUE ESTA CLASSE ANTES DE VERIFICAR
 *  O DIAGRAMA DE SEQUENCIA CONSTANTE NA APOSTILA !
 *  ------------------------------------------------
 */
public class AdicionarProdutoCarrinho extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            Produto produtoSelecionado = getProdutoSelecionado(request);
            adicionarProdutoCarrinho(request, produtoSelecionado);
            RequestDispatcher dispatcher = request.getRequestDispatcher("exibeCarrinhoCompras");
            dispatcher.forward(request, response);
        } catch (GlobalcodeException e) {
            throw new ServletException(e);
        }
    }

    private Produto getProdutoSelecionado(HttpServletRequest request) throws GlobalcodeException, ServletException {
        String strIdProdutoSelecionado = request.getParameter("idProduto");
        if (strIdProdutoSelecionado != null) {
            int idProdutoSelecionado = Integer.parseInt(strIdProdutoSelecionado);
            ProdutosDAO dao = new ProdutosDB();
            Produto p = dao.getProdutoById(idProdutoSelecionado);
            System.out.println("[AdicionarProdutoCarrinho:getProdutoSelecionado] Produto selecionado ");
            System.out.println(p);
            return p;
        } else {
            throw new ServletException("Produto naum encontrado - id: " + strIdProdutoSelecionado);
        }
            
    }

    private void adicionarProdutoCarrinho(HttpServletRequest request, Produto produtoSelecionado) {
        System.out.println(produtoSelecionado);
        // Criando um novo item com o produto selecionado, quantidade igual a 1
        Item item = new Item(produtoSelecionado, 1);
        
        // --------------------------------------------------------------------
        // 1) Obter o objeto HttpSession.
        // --------------------------------------------------------------------
        // solucao
        HttpSession sessao = request.getSession();
        
        // --------------------------------------------------------------------        
        // 2) Obter do escopo de sessao o carrinho de compras com o nome 
        //    "carrinhoCompras". 
        //    Sera necessario utilizar uma operacao de cast-down.
        // --------------------------------------------------------------------
        CarrinhoCompras carrinho = null;
        // solucao
        carrinho = (CarrinhoCompras) sessao.getAttribute("carrinhoCompras");
        
        if (carrinho == null) { // se o carrinho de compras ainda n�o existe ...
            // Criando o objeto carrrinho de compras 
            // passando o item como parametro no construtor
            carrinho = new CarrinhoCompras(item);
            // --------------------------------------------------------------------
            // 3) Armazenar no escopo de sessao o carrinho como um 
            //    atributo nomeado "carrinhoCompras".
            // --------------------------------------------------------------------
            // solucao            
            sessao.setAttribute("carrinhoCompras", carrinho);
            
        } else { // se o carrinho de compras ja existe ...
            // Adicionando o item no carrinho atraves do metodo addItem
            carrinho.addItem(item);
        }
    }
}
