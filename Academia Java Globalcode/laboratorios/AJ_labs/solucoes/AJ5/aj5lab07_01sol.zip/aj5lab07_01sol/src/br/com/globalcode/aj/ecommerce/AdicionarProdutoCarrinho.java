package br.com.globalcode.aj.ecommerce;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import br.com.globalcode.aj.dao.ProdutosDAO;
import br.com.globalcode.aj.dao.ProdutosDB;
import br.com.globalcode.beans.CarrinhoCompras;
import br.com.globalcode.beans.Item;
import br.com.globalcode.beans.Produto;
import br.com.globalcode.util.GlobalcodeException;

public class AdicionarProdutoCarrinho extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            Produto produtoSelecionado = getProdutoSelecionado(request);
            adicionarProdutoCarrinho(request, produtoSelecionado);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/CarrinhoComprasView.jsp");
            dispatcher.forward(request, response);
        } catch (GlobalcodeException e) {
            throw new ServletException(e);
        }
    }

    private Produto getProdutoSelecionado(HttpServletRequest request) throws GlobalcodeException, ServletException {
        String strIdProdutoSelecionado = request.getParameter("idProduto");
        if (strIdProdutoSelecionado != null) {
            int idProdutoSelecionado = Integer.parseInt(strIdProdutoSelecionado);
            ProdutosDAO dao = new ProdutosDB();
            Produto p = dao.getProdutoById(idProdutoSelecionado);
            System.out.println("[AdicionarProdutoCarrinho:getProdutoSelecionado] Produto selecionado ");
            System.out.println(p);
            return p;
        } else {
            throw new ServletException("Produto naum encontrado - id: " + strIdProdutoSelecionado);
        }
            
    }

    private void adicionarProdutoCarrinho(HttpServletRequest request, Produto produtoSelecionado) {
        System.out.println(produtoSelecionado);
        // 1) Obter a Session
        HttpSession sessao = request.getSession();
        // 2) Criar o item com o produto selecionado, quantidade igual a 1
        Item item = new Item(produtoSelecionado, 1);
        // 3) Obter o carrinho de compras com o nome ("carrinhoCompras")
        CarrinhoCompras carrinho = (CarrinhoCompras) sessao.getAttribute("carrinhoCompras");
        // 4) Se o carrinho de compras for igual a null, cria-lo passando o item como parametro no construtor
        if (carrinho == null) {
            carrinho = new CarrinhoCompras(item);
            // 4.1) Adicionar o carrinho criado com o nome "carrinhoCompras"
            sessao.setAttribute("carrinhoCompras", carrinho);
        } else {
            // 5) Se o carrinho de compras nao for null adicionar o item no carrinho atraves do metodo addItem
            carrinho.addItem(item);
        }
    }
}
