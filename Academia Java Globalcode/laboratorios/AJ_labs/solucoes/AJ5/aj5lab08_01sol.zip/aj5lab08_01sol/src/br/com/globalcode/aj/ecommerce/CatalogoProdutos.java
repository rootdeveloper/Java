/*
 * CatalogoProdutos.java
 *
 */
package br.com.globalcode.aj.ecommerce;

import br.com.globalcode.aj.dao.ProdutosDAO;
import br.com.globalcode.aj.dao.ProdutosDB;
import br.com.globalcode.util.ComparadorProdutos;
import br.com.globalcode.util.GlobalcodeException;
import java.util.Collections;
import java.util.List;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CatalogoProdutos extends HttpServlet {
  
  private ComparadorProdutos comparador = null;
  
  public void init() {
      String initParamCriterioOrdenacao = getServletConfig().getInitParameter("criterio-ordenacao");
      byte criterioOrdenacao = Byte.parseByte(initParamCriterioOrdenacao);
      comparador = new ComparadorProdutos(criterioOrdenacao);
  }
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
        ProdutosDAO produtosDB = new ProdutosDB();
        List listaProdutos = null;
        try {
            listaProdutos = produtosDB.getCatalogoProdutos();
        } catch (GlobalcodeException e) {
            throw new ServletException(e);
        }
        
        Collections.sort(listaProdutos, comparador);        
        
        request.setAttribute("catalogo", listaProdutos);
        RequestDispatcher despachante = request.getRequestDispatcher("/jsp/CatalogoProdutosView.jsp");
        despachante.forward(request, response);
        
  }
  
}
