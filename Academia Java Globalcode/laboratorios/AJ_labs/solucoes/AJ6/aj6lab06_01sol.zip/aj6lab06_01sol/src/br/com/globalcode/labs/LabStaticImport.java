package br.com.globalcode.labs;

import static java.util.Calendar.*;
import java.util.GregorianCalendar;

public class LabStaticImport {
    public static void main(String[] args){
        // Mude para static import e fa�a as altera��es necess�rias
        GregorianCalendar cal = new GregorianCalendar();
        boolean ok = cal.get(DAY_OF_WEEK) == SATURDAY;
        System.out.println("hoje e sabado ? "+ok);
    }
}
