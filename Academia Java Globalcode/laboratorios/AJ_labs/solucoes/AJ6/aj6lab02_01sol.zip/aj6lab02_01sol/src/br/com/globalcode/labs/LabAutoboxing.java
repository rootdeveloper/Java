package br.com.globalcode.labs;
import java.util.*;

public class LabAutoboxing {
    public static void main(String[] args){
        int i = 10;
        List numeros = new ArrayList();
        // Adicione a variavel i ao List numeros
        numeros.add(i);        
        // Obtenha os elementos do List numeros e armazene novamente na variavel i
        i = (Integer)numeros.get(0);
        System.out.println("i="+i);
        Integer i2 = new Integer(10);
        // Some os valores de i2 e i e armazene na variavel total
        Integer total;
        total = i2 + i;        
        System.out.println("total="+total);
        // Some os valores da variavel total e da variavel i e armazene na variavel i novamente
        i = i + total;        
        System.out.println("i="+i);
    }
}
