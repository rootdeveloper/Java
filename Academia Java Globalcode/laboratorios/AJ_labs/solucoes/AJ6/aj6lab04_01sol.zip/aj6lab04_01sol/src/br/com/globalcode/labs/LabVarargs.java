package br.com.globalcode.labs;
import java.util.*;

public class LabVarargs {
    public static void main(String[] args){
        comVarargs(1,3,5,7);
        comVarargs2("Maria", "Joao", "Alice");
    }
    public static void comVarargs(int ... numeros){
        for (int i = 0; i< numeros.length; i++){
            System.out.println(numeros[i]);
        }
    }
    public static void comVarargs2(String ... nomes){
        for (int i = 0; i< nomes.length; i++){
            System.out.println(nomes[i]);
        }
    }
}
