package br.com.globalcode.labs;

public class TesteRetornoCovariante {
    
 public static void main(String[] args){
     // Inicialize um objeto da classe Inteiro
     Inteiro i = new Inteiro(10);
     // Declare uma variavel chamada numero do tipo int para receber o retorno do metodo getNumero
     int numero = i.getNumero();
     // Imprima o valor da variavel numero
     System.out.println(numero);
     // Inicialize um objeto da classe Real
     Real r    = new Real(10.5f);
     // Declare uma variavel do tipo float para receber o retorno do metodo getNumero
     float numero2 = r.getNumero();
     // Imprima o valor da variavel numero2
     System.out.println(numero2);
     
 }
}
