package br.com.globalcode.labs;
import java.util.*;

public class Inteiro implements INumero {
    // Declare um atributo chamado numero do tipo int    
    int numero;
    // Declare um construtor que receba um int e inicialize o atributo numero    
    public Inteiro(int numero){
        this.numero = numero;
    }
    // Implemente o metodo getNumero retornando um Integer ao inves de um Object (retorno covariante)
    public Integer getNumero(){
        return this.numero;
    }
}
