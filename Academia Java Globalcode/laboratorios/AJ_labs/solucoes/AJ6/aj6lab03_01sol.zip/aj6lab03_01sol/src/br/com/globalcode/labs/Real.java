package br.com.globalcode.labs;
import java.util.*;

public class Real implements INumero {
    // Declare um atributo chamado numero do tipo float    
    float numero;
    // Declare um construtor que receba um float e inicialize o atributo numero    
    public Real(float numero){
        this.numero = numero;
    }
    // Implemente o metodo getNumero retornando um Float ao inves de um Object (retorno covariante)
    public Float getNumero(){
        return this.numero;
    }
}
