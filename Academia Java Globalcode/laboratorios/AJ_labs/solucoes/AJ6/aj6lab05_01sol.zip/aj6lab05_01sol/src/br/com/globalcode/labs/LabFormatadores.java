package br.com.globalcode.labs;
import java.util.*;

public class LabFormatadores {
    public static void main(String[] args){
        // Informe a data no formato dd/mm/yyyy e a hora completa hh:mm:ss
        Date data = new Date();
        System.out.printf("Hoje � %1$td/%1$tm/%1$tY e s�o %1$tT horas. %n",data);
        // Mostre o n�mero inteiro com 6 d�gitos e zeros � esquerda e o n�mero double com as 2 decimais
        int i = 101;
        double numero = 23.45;
        System.out.printf("Inteiro = %1$06d e Decimal = %2$5.2f. %n",i,numero);
    }
}
