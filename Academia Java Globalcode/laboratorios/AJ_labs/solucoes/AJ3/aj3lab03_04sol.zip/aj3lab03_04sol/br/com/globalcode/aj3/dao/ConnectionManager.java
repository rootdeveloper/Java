package br.com.globalcode.aj3.dao;

/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 */
import java.sql.*;
import br.com.globalcode.util.GlobalcodeException;

public class ConnectionManager {

    // 1) Coloque o valor adequado nas constantes DATABASE, USER, IP e PASSWORD
    // 2) Teste esta classe para garantir que esta funcionando
    private static final String STR_DRIVER = "org.gjt.mm.mysql.Driver";
    private static final String DATABASE = "aj";
    private static final String IP = "192.168.0.1";
    private static final String STR_CON = "jdbc:mysql://" + IP + ":3306/" + DATABASE;
    private static final String USER = "aj";
    private static final String PASSWORD = "aj";

    public static Connection getConexao() throws GlobalcodeException {
        Connection conn = null;
        try {
            // 3) Faca o carregamento do driver
            Class.forName(STR_DRIVER);
            // 4) Obtenha a conexao
            conn = DriverManager.getConnection(STR_CON, USER, PASSWORD);
            System.out.println("[ConnectionManager]: Obtendo conexao");
            return conn;
        } catch (ClassNotFoundException e) {
            String errorMsg = "Driver nao encontrado";
            throw new GlobalcodeException(errorMsg, e);
        } catch (SQLException e) {
            String errorMsg = "Erro ao obter a conexao";
            throw new GlobalcodeException(errorMsg, e);
        }
    }

    public static void closeAll(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            String errorMsg = "Nao foi possivel fechar a conexao com o banco";
            GlobalcodeException.print(e, errorMsg);
        }
    }

    public static void closeAll(Connection conn, Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (Exception e) {
            String errorMsg = "Nao foi possivel fechar o Statement";
            GlobalcodeException.print(e, errorMsg);
        }
        closeAll(conn);
    }

    public static void closeAll(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            String errorMsg = "Nao foi possivel fechar o Resultset";
            GlobalcodeException.print(e, errorMsg);
        }
        closeAll(conn, stmt);
    }
}
