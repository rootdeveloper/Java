/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 */
package br.com.globalcode.aj3.dao;

import java.util.List;
import java.sql.*;
import br.com.globalcode.beans.Cliente;
import br.com.globalcode.util.GlobalcodeException;

/**
 * @author Globalcode
 * 
 */
public class ClientesDB implements ClientesDAO {

    private final static String SALVAR_CLIENTE = "INSERT INTO clientes (nome,cpf,telefone) VALUES (?,?,?)";
    private final static String CREATE_TABLE = "CREATE TABLE  IF NOT EXISTS  clientes (id int(3) NOT NULL AUTO_INCREMENT   PRIMARY KEY, nome VARCHAR(20) NOT NULL, cpf varchar(20) NOT NULL, telefone varchar(20) NOT NULL)";
    private final static String DELETE_CLIENTE = "DELETE FROM clientes WHERE cpf = '";
    private final static String GET_ALL_CLIENTES = "SELECT * FROM clientes";
    private final static String GET_CLIENTE_BY_CPF = "SELECT * FROM clientes WHERE cpf = ?";

    public void createTable() throws GlobalcodeException {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = ConnectionManager.getConexao();
            stmt = conn.createStatement();
            stmt.executeUpdate(CREATE_TABLE);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new GlobalcodeException("Erro ao criar a tabela de clientes : " + CREATE_TABLE, e);
        } finally {
            ConnectionManager.closeAll(conn, stmt);
        }
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#excluir(br.com.globalcode.beans.Cliente)
     */
    public void excluir(String cpf) throws GlobalcodeException {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = ConnectionManager.getConexao();
            // Obtem uma conexao com o servidor
            stmt = conn.createStatement();
            // Cria o statement responsavel pelo envio dos SQL's
            stmt.executeUpdate(DELETE_CLIENTE + cpf + "'");
            // Executa a query passando como parametro o CPF
        } catch (SQLException e) {
            String errorMsg = "Nao foi possivel fechar o statement com o banco de Dados!";
            e.printStackTrace();
            throw new GlobalcodeException(errorMsg, e);
        }
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#salvar(br.com.globalcode.beans.Cliente)
     */
    public void salvar(Cliente cliente) {
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#getAllClientes()
     */
    public List getAllClientes() throws GlobalcodeException {
        // 1.Instanciar um objeto da classe ArrayList (list) com o construtor default
        // 2. Implemente a busca de todos os cliente do banco de dados
        // utilizando a constante GET_ALL_CLIENTES
        // 3. Obter o ResultSet (definir a instancia deste ResultSet como rs) da busca
        // 4. navegar por ele (usando um while(rs.next())
        // 4a Usar os metodos rs.getXXX(String nomeColuna) para obter os dados do ResultSet
        // das colunas para os respectivos atributos
        // 4b Instanciar uma classe Cliente com os parametros do construtor obtidos atravess da consulta
        // 4c Adicionar o objeto cli ao ArrayList (list.add(cli);)
        // 5. Retornar O ArrayList que foi instanciado
    }

    /*
     * (non-Javadoc)
     * 
     * @see br.com.globalcode.aj3.dao.ClientesDAO#getClienteByID(int)
     */
    public Cliente getClienteByCPF(String cpf) {
        return null;
    }
}
