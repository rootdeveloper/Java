package br.com.globalcode.io;

import br.com.globalcode.util.GlobalcodeException;

/*
 * Importante:
 * Este codigo sera utilizado pela classe EditorTexto por isto:
 *  
 * 1. Nao altere a assinatura dos metodos desta classe, ou seja, mantenha todos 
 * os modificadores, os parametros e as exceptions lan�adas.
 * 2. Nao altere o nome desta classe
 * 3. Implemente os metodos conforme especificado abaixo
 * 4. Depois que a classe FileSaver estiver testada e funcionando execute a classe 
 * EditorTexto e analise seu codigo.
 * 
 * OBS: Na abertura dos arquivos, o texto aberto estara deslocado em rela�ao a
 * atual tela. Para confirmar a abertura do arquivo, utilize as barras de rolagem 
 * na tela de edi�ao.
 * 
 */
public class FileSaver {

    public static void save(String texto, String fileName) throws GlobalcodeException {
        // Utilizando a classe FileWriter implemente este metodo de forma que o texto seja
        // gravado no arquivo indicado pelo parametro fileName.
        // - opcionalmente a classe BufferedWriter pode ser utilizada
        // - nao se esqueca de executar os metodos flush e close nos seus streams de caracteres
        
    }

    public static String read(String fileName) throws GlobalcodeException {
        
        // Utilizando a classe FileReader implemente este metodo de forma que o texto seja
        // lido do arquivo indicado pelo parametro fileName 
        // - No modulo AJ1 verificamos que a classe java.lang.StringBuffer 
        //   eh muito eficiente para operacoes de modificacao de cadeias de caracteres.
        //   Se achar necessario solicite ao seu instrutor uma rapida revisao desta classe.
        // - opcionalmente a classe BufferedReader pode ser utilizada
        // - nao se esqueca de executar os metodos close nos seus streams de caracteres
        
        return null; // apague esta linha
        
    }
}
