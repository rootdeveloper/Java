/**
 * @author Globalcode 
 * TesteGravacaoCliente.java
 */

package br.com.globalcode.teste;

import br.com.globalcode.beans.Cliente;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TesteGravacaoCliente {
    
    public static void main(String[] args) {
        
        Cliente cliente1 = new Cliente("Joao da Silva", "11-8558-7447", "11232404-6", 1);
        String nomeArquivo1 = "Cliente" + cliente1.getCpf() + ".ser";
        
        
        try {
            FileOutputStream gravador = new FileOutputStream(nomeArquivo1);
            
            /*
             * 1. Instacie um stream de gravacao de objetos (ObjectOutputStream)
             * baseado no stream de arquivos "gravador".
             *
             * 2. Envie o objeto cliente1 para o stream de saida de gravacao
             * de objetos
             */
            ObjectOutputStream gravadorObjetos = null;
            



            // fechando os streams
            gravadorObjetos.flush();
            gravadorObjetos.close();
            gravador.close();
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        
    }
    
}
