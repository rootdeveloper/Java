/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 */
package br.com.globalcode.aj4.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;
import br.com.globalcode.aj4.gui.eventos.EventosMouse;
import br.com.globalcode.beans.Cliente;
import br.com.globalcode.util.GlobalcodeException;

public class PanelCadastroClientes extends JPanel {

    private JLabel lNome;
    private JTextField tfNome;
    private JLabel lTelefone;
    private JTextField tfTelefone;
    private JLabel lCPF;
    private JTextField tfCPF;
    private JLabel lID;
    private JTextField tfID;
    private JPanel pCadastroCliente;
    private JPanel pBotoesCadastro;
    private JButton bExcluir;
    private JButton bSalvar;
    private JButton bNovo;

    /**
     * Este construtor monta um Panel para insercao de dados de Cadastro de Clientes,
     */
    public PanelCadastroClientes() throws GlobalcodeException {
        this.setLayout(new BorderLayout());
        // Montagem do panel para inser�ao ou edi�ao de um cliente
        pCadastroCliente = montaPanelCadastroCliente();
        // Montagem do panel com botoes para salvar ou excluir clientes
        pBotoesCadastro = montaPanelBotoesCadastro();
        /*
         * Adicao dos paineis pCadastroCliente e pBotoesCadastro no panel principal
         */
        this.add(pCadastroCliente, BorderLayout.CENTER);
        this.add(pBotoesCadastro, BorderLayout.SOUTH);
    }

    /**
     * Metodo utilizado internamente para montagem do JPanel com o botao Salvar, por isto ele foi declarado como
     * private.
     * 
     * @return JPanel com o botao Salvar, para salvar um cliente
     */
    private JPanel montaPanelBotoesCadastro() {
        JPanel pBotoesCadastro = new JPanel();
        bSalvar = new JButton("Salvar");
        bSalvar.setMnemonic(KeyEvent.VK_S);
        // 2 - Altere a associacao ao EventosMouse para SalvarClienteHandler 
        bSalvar.addMouseListener(new EventosMouse());
        bNovo = new JButton("Novo");
        bNovo.setMnemonic(KeyEvent.VK_N);
        bExcluir = new JButton("Excluir");
        bExcluir.setMnemonic(KeyEvent.VK_E);
        pBotoesCadastro.add(bSalvar);
        pBotoesCadastro.add(bExcluir);
        pBotoesCadastro.add(bNovo);
        return pBotoesCadastro;
    }

    /**
     * Metodo utilizado internamente para montagem do JPanel para cadastro ou edicao de um cliente, por isto ele foi
     * declarado como private.
     * 
     * @return JPanel para cadastro ou edicao de um cliente
     * 
     */
    private JPanel montaPanelCadastroCliente() {
        JPanel pCadastroCliente = new JPanel();
        GridLayout layout = new GridLayout(8, 1);
        pCadastroCliente.setLayout(layout);
        lNome = new JLabel("Nome:");
        tfNome = new JTextField();
        lTelefone = new JLabel("Telefone:");
        tfTelefone = new JTextField();
        lCPF = new JLabel("CPF:");
        tfCPF = new JTextField();
        lID = new JLabel("ID:");
        tfID = new JTextField();
        tfID.setEditable(false);
        pCadastroCliente.add(lNome);
        pCadastroCliente.add(tfNome);
        pCadastroCliente.add(lTelefone);
        pCadastroCliente.add(tfTelefone);
        pCadastroCliente.add(lCPF);
        pCadastroCliente.add(tfCPF);
        pCadastroCliente.add(lID);
        pCadastroCliente.add(tfID);
        return pCadastroCliente;
    }

    /**
     * Metodo utilizado internamente para fazer a limpeza dos JTextFields dados do cliente.
     * 
     */
    private void clearClienteFromPanel() {
        // 4.3 - Atribuir a cada um dos JTextFields (tfXXX) o valor "" (String vazia) usando o metodo setText(String)
        System.out.println("Limpando o painel de cadastro de clientes");
    }

    /**
     * Metodo utilizado internamente para fazer a leitura dos dados do cliente dos 
     * JTextFields referentes aos dados do cliente, cria um objeto da classe Cliente 
     * e retorna o Cliente.
     * 
     * @return Cliente com os dados obtidos dos JTextFields apresentados
     * 
     */
    private Cliente loadClienteFromPanel() throws GlobalcodeException {
        System.out.println("Carregando o cliente em edi�ao para um objeto da classe Cliente");
        // 4.1 - Obter cada um dos dados digitados nos JTextFields (tfXXX) usando o metodo getText()
        //  4.1.a - Armazene-os temporariamente em variaveis para uso posterior
        //  4.1.b - Instanciar uma classe do tipo cliente que ira receber os valores armazenados acima
        //  4.1.c - Retornar o cliente
        return null;
    }

    /**
     * Metodo utilizado internamente para fazer a escrita dos dados do cliente dentro 
     * dos JTextFields.
     * 
     * @param cliente
     *            Informacoes do cliente provenientes de uma base de dados externa
     * 
     */
    private void loadClienteToPanel(Cliente c) {
        // 4.2 - Analisar inicialmente se o cliente passado nao e nulo.
        //  4.2.a - Caso seja nao execute nada
        //  4.2.b - Atribuir o valor do tfXXX usando o metodo setText(String) 
        //          com os dados do cliente recebido no parametro
    }

    class SalvarClienteHandler extends MouseAdapter {
        // 1 - Implementar nesta classe interna o metodo para o evento mouseClicked
        //     No primeiro momento voce devera apenas colocar a instrucao de impressao
        //     System.out.println("[SalvarClienteHandler] mouseClicked");
        
        // 5 - No metodo mouseClicked, voce devera colocar a criacao de um objeto do tipo Cliente
        // empregando o metodo da classe PanelCadastroCliente loadClienteFromPanel()
    }
}