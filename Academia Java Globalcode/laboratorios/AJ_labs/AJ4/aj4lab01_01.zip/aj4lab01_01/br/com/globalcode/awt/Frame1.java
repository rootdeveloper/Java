package br.com.globalcode.awt;

import java.awt.*;

public class Frame1 extends Frame {

    public Frame1(String title) {
        // Estamos indicando o titulo da janela
        this.setTitle(title);
        // Configuracao do tamanho da janela
        this.setSize(200, 100);
        // Fazendo a janela aparecer
        this.setVisible(true);
    }

    // Ao executar a classe o metodo main sera executado, criando uma instancia do
    // Frame1, que por sua vez faz com que a janela seja exibida.
    public static void main(String args[]) {
        Frame1 janela = new Frame1("Titulo da Janela");
    }
}
