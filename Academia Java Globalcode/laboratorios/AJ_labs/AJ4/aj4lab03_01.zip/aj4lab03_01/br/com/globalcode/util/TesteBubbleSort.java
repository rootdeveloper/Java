/*
 * TesteBubbleSort.java
 *
 *
 */
package br.com.globalcode.util;

/**
 * 
 * @author Globalcode
 */
public class TesteBubbleSort {

    public static void main(String[] args) {
        String[] nomes = { "Nair", "Anselmo", "Francisco", "Ana", "Marcos", "Paulo" };
        BubbleSort buble = new BubbleSort(nomes);
        buble.ordenar();
        for (int i = 0; i < nomes.length; i++) {
            System.out.println(nomes[i]);
        }
    }
}
