/*
 * ListModelUtil.java
 *
 * Created on 22 de Mar�o de 2006, 11:39
 *
 */
package br.com.globalcode.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.DefaultListModel;
import javax.swing.ListModel;

/**
 * 
 * @author Globalcode
 */
public class ListModelUtil {

    public static ListModel toListModel(Comparable[] array) {
        DefaultListModel listModel = new DefaultListModel();
        for (int i = 0; i < array.length; i++) {
            listModel.addElement(array[i]);
        }
        return listModel;
    }

    public static Comparable[] toArray(ListModel listModel) {
        Comparable[] array = new Comparable[listModel.getSize()];
        for (int i = 0; i < array.length; i++) {
            array[i] = (Comparable) listModel.getElementAt(i);
        }
        return array;
    }

    public static ListModel carregaListModel(File arquivo, int qtdMaxima) throws IOException {
        FileReader fr = null;
        BufferedReader br = null;
        int count = 0;
        try {
            fr = new FileReader(arquivo);
            br = new BufferedReader(fr);
            DefaultListModel listModel = new DefaultListModel();
            String linha = null;
            while ((linha = br.readLine()) != null) {
                listModel.addElement(linha);
                if (++count >= qtdMaxima) {
                    break;
                }
            }
            return listModel;
        } finally {
            if (br != null)
                br.close();
            if (fr != null)
                fr.close();
        }
    }
}
